<?php
  $file1 = '116010.jpg';
  $product1 = 'Artist Holding a Thistle';
  $quantity1 = 3;
  $price1 = 500;

  $file2 = '113010.jpg';
  $product2 = 'Self-portrait in a Straw Hat';
  $quantity2 = 1;
  $price2 = 700;
?>